

// var setup = function(squaresBorough, burName,white, hispanic, black, asian, callback){
//     //width = window.innerWidth*(popBurough/totalPopulation);

//     var w = 1060, h = 460;
//     width = (w*squaresBorough)/totalSquares; 
//     x=0,y=0;
//     var numberofsquare = Math.ceil((width*h)/(sideSquare*sideSquare));
    
//     if(d3.select("svg."+burName).node()){
//         var svg = d3.select("svg."+burName);
//     }else{
//         var svg=d3.select(".boroughsContainer").append("svg")
//          .attr("width",width)
//          .attr("height",h)
//          .attr("class",burName);    
//     }
//     numberofsquare = drawSquares(numberofsquare,svg, "#ccc",true,burName,squaresBorough);
//     x=0,y=0;
//     var whitesq = numberofsquare*white; 
//     var hispanicsq = numberofsquare*hispanic;
//     var blacksq = numberofsquare*black;  
//     var asiansq = (numberofsquare - whitesq-hispanicsq-blacksq); 
//     drawSquares(whitesq, svg, "#ffff66",undefined,undefined,white*squaresBorough);
//     drawSquares(hispanicsq, svg, "#ccff66",undefined,undefined,hispanic*squaresBorough);
//     drawSquares(blacksq, svg, "#ff6600",undefined,undefined,black*squaresBorough);
//     drawSquares(asiansq, svg, "#ccffff",undefined,undefined,asian*squaresBorough);
    
// }

var projectTitle = function(){

}
   


function hide_stuff(hide_01,hide_02){
    if(hide_01){
        $(".displaytext1").hide(); 
    }
    if(hide_02){
        $(".displaytext2").hide(); 
    }


};

hide_stuff(true,true);
$(".key").hide(); 
 $('.displaytext3').css('display','none');


d3.selectAll(".btn").on("click",function(){

    var val = d3.select(event.target).html();
    if(val=="1" || val=="CLICK"){
        $('#chartgraphs').css('display','none');
        // drawBuroughs(); 
        setInterval(function(){ $(".chart1").css("display","block")}, 3000);
        $(".intro").css("display","none");
        $(".displaytext1").show(); 
        $('.displaytext2').css('display','none');
        $('.displaytext3').css('display','none');
        hide_stuff(false,true, true);
        $(".key").hide(); 

$.get('boroughs.svg', function(data) {
        var svg=$(document.body).append(data.documentElement);
$('#basequares').fadeto("slow",0.25);

    $('#brooklynactivate').hide();
    $('#queensactivate').hide();
    $('#manhattanactivate').hide();
    $('#bronxactivate').hide();
    $('#statenactivate').hide();
            
    $('#brooklynbutton').hover(
        function mouseover() {
    $('#brooklynactivate').show();
    }, 
        function mouseleave() {
        $('brooklynactivate').hide();
    });

    $('#queeensbutton').hover(
        function mouseover() {
    $('#queensactivate').show();
    }, 
        function mouseleave() {
        $('queensactivate').hide();
    });

    $('#manhattanbutton').hover(
        function mouseover() {
    $('#manhattanactivate').show();
    }, 
        function mouseleave() {
        $('#manhattanactivate').hide();
    });

    $('#bronxbutton').hover(
        function mouseover() {
    $('#bronxactivate').show();
    }, 
        function mouseleave() {
        $('#bronxactivate').hide();
    });

    $('#statenbutton').hover(
        function mouseover() {
    $('#statenactivate').show();
    }, 
        function mouseleave() {
        $('#statenactivate').hide();
     });

  

});
/////////////
        $(".key").hide(); 

    }else if(val=="2"){
        $('#chartgraphs').css('display','none');
        $('.displaytext1').css('display','none');
        $(".displaytext2").show(); 
        $(".key").show(); 
        $('.displaytext3').css('display','none');
        // drawRaces();
        hide_stuff(true,false);


        $.get('idealraces.svg', function(data) {
        var svg=$(document.body).append(data.documentElement);
        $('#idealbase').fadeto("slow",0.25);

        $('#brooklynwhiteactivate').hide();
        $('#brooklynafricanactivate').hide();
        $('#brooklynasianactivate').hide();
        $('#brooklynotheractivate').hide();
        $('#brooklynhispanicactivate').hide();

        $('#queenswhiteactivate').hide();
        $('#queensafricanactivate').hide();
        $('#queensasianactivate').hide();
        $('#queensnotheractivate').hide();
        $('#queenshispanicactivate').hide();

        $('#manhattanwhiteactivate').hide();
        $('#manhattanafricanactivate').hide();
        $('#manhattanasianactivate').hide();
        $('#manhattannotheractivate').hide();
        $('#manhattanhispanicactivate').hide();


        $('#bronxwhiteactivate').hide();
        $('#bronxafricanactivate').hide();
        $('#bronxindianactivate').hide();
        $('#bronxasianactivate').hide();
        $('#bronxotheractivate').hide();
        $('#bronxhispanicactivate').hide();

        $('#statenwhiteactivate').hide();
        $('#statenafricanactivate').hide();
        $('#statenasianactivate').hide();
        $('#statennotheractivate').hide();
        $('#statenhispanicactivate').hide();


//Brooklyn mouse over moves for each race 
        $('#brooklynwhitebutton').hover(
            function mouseover() {
        $('#brooklynwhiteactivate').show();
        }, 
        function mouseleave() {
        $('#brooklynwhiteactivate').hide();
        });

        $('#brooklynafricanbutton').hover(
            function mouseover() {
        $('#brooklynafricanactivate').show();
        }, 
        function mouseleave() {
        $('#brooklynafricanactivate').hide();
        });


        $('#brooklynasianbutton').hover(
            function mouseover() {
        $('#brooklynasianactivate').show();
        }, 
        function mouseleave() {
        $('#brooklynasianactivate').hide();
        });


        $('#brooklynotherbutton').hover(
            function mouseover() {
        $('brooklynotheractivate').show();
        }, 
        function mouseleave() {
        $('#brooklynotheractivate').hide();
        });


        $('#brooklynhispanicbutton').hover(
        function mouseover() {
        $('#brooklynhispanicactivate').show();
        }, 
        function mouseleave() {
        $('#brooklynhispanicactivate').hide();
           });

        //Queens mouse over moves for each race 
        $('#queenswhitebutton').hover(
            function mouseover() {
        $('#queenswhiteactivate').show();
        }, 
        function mouseleave() {
        $('#queenswhiteactivate').hide();
        });

        $('#queensafricanbutton').hover(
            function mouseover() {
        $('#queensafricanactivate').show();
        }, 
        function mouseleave() {
        $('#queensafricanactivate').hide();
        });


        $('#queensasianbutton').hover(
            function mouseover() {
        $('#queensasianactivate').show();
        }, 
        function mouseleave() {
        $('#queensasianactivate').hide();
        });


        $('#queensotherbutton').hover(
            function mouseover() {
        $('#queensotheractivate').show();
        }, 
        function mouseleave() {
        $('#queensotheractivate').hide();
        });


        $('#queenshispanicbutton').hover(
        function mouseover() {
        $('#queenshispanicactivate').show();
        }, 
        function mouseleave() {
        $('#queenshispanicactivate').hide();
           });


 //Manhattan mouse over moves for each race 
        $('#manhattanwhitebutton').hover(
            function mouseover() {
        $('#manhattanwhiteactivate').show();
        }, 
        function mouseleave() {
        $('#manhattanwhiteactivate').hide();
        });

        $('#manhattanafricanbutton').hover(
            function mouseover() {
        $('#manhattanafricanactivate').show();
        }, 
        function mouseleave() {
        $('#manhattanafricanactivate').hide();
        });


        $('#manhattanasianbutton').hover(
            function mouseover() {
        $('#manhattanasianactivate').show();
        }, 
        function mouseleave() {
        $('#manhattanasianactivate').hide();
        });


        $('#manhattanotherbutton').hover(
            function mouseover() {
        $('#bronxotheractivate').show();
        }, 
        function mouseleave() {
        $('#manhattanotheractivate').hide();
        });


        $('#manhattanhispanicbutton').hover(
        function mouseover() {
        $('#manhattanhispanicactivate').show();
        }, 
        function mouseleave() {
        $('#manhattanhispanicactivate').hide();
           });

 //Bronx mouse over moves for each race 
        $('#bronxwhitebutton').hover(
            function mouseover() {
        $('#bronxwhiteactivate').show();
        }, 
        function mouseleave() {
        $('#bronxwhiteactivate').hide();
        });

        $('#bronxafricanbutton').hover(
            function mouseover() {
        $('#bronxafricanactivate').show();
        }, 
        function mouseleave() {
        $('#bronxafricanactivate').hide();
        });

        $('#bronxindianbutton').hover(
            function mouseover() {
        $('#bronxindianactivate').show();
        }, 
        function mouseleave() {
        $('#bronxindianactivate').hide();
        });


        $('#bronxasianbutton').hover(
            function mouseover() {
        $('#bronxasianactivate').show();
        }, 
        function mouseleave() {
        $('#bronxasianactivate').hide();
        });


        $('#bronxotherbutton').hover(
            function mouseover() {
        $('#bronxotheractivate').show();
        }, 
        function mouseleave() {
        $('#bronxotheractivate').hide();
        });


        $('#bronxhispanicbutton').hover(
        function mouseover() {
        $('#bronxhispanicactivate').show();
        }, 
        function mouseleave() {
        $('#bronxhispanicactivate').hide();
           });

//Staten Island mouse over moves for each race 
        $('#statenwhitebutton').hover(
            function mouseover() {
        $('#statenwhiteactivate').show();
        }, 
        function mouseleave() {
        $('#statenwhiteactivate').hide();
        });

        $('#statenafricanbutton').hover(
            function mouseover() {
        $('#statenafricanactivate').show();
        }, 
        function mouseleave() {
        $('#statenafricanactivate').hide();
        });


        $('#statenasianbutton').hover(
            function mouseover() {
        $('#statenasianactivate').show();
        }, 
        function mouseleave() {
        $('#statenasianactivate').hide();
        });


        $('#statenotherbutton').hover(
            function mouseover() {
        $('#statenotheractivate').show();
        }, 
        function mouseleave() {
        $('#statenotheractivate').hide();
        });


        $('#statenhispanicbutton').hover(
        function mouseover() {
        $('#statenhispanicactivate').show();
        }, 
        function mouseleave() {
        $('#statenhispanicactivate').hide();
           });
      

});
/////////////
        // $(".key").hide(); 

    }else if(val=="3"){
        $('#chartgraphs').css('display','none');
        $('.displaytext1').css('display','none');
        $('.displaytext2').css('display','none');

        // $(".displaytext2").show(); 
        $(".key").show(); 
        $(".displaytext3").show(); 

        // drawRaces();
        hide_stuff(true,false);
    
    $.get('realraces_use.svg', function(data) {
    var svg=$(document.body).append(data.documentElement);
    $('#realsquarebase').fadeto("slow",0.25);


    $('#activateda').hide();
    $('#activatedb').hide();
    $('#activatedc').hide();
    $('#activatedd').hide();
    $('#activatede').hide();
            

    $('#buttona').hover(
        function mouseover() {
    $('#activateda').show();
    }, 
        
        function mouseleave() {
        $('#activateda').hide();
    });

    $('#buttonb').hover(
        function mouseover() {
    $('#activatedb').show();
    }, 
        
        function mouseleave() {
        $('#activatedb').hide();
    });

    $('#buttonc').hover(
        function mouseover() {
    $('#activatedc').show();
    }, 
        
        function mouseleave() {
        $('#activatedc').hide();
    });

$('#buttond').hover(
        function mouseover() {
    $('#activatedd').show();
    }, 
        
        function mouseleave() {
        $('#activatedd').hide();
    });

    $('#buttone').hover(
        function mouseover() {
    $('#activatede').show();
    }, 
        
        function mouseleave() {
        $('#activatede').hide();
      });

  

});
/////////////

    }

    else if(val=="4"){

        $('.boroughsContainer').css('display','none')
        $(".intro").css("display","none");
        $('.displaytext1').css('display','none');
        $('.displaytext2').css('display','none');
        $('.displaytext3').css('display','none');
        $(".key").show(); 
        // $('#chartgraphs').css('display','block');

         //////////////////
$.get('graphspage.svg', function(data) {

    var svg=$(document.body).append(data.documentElement);

    $('#activateda').hide();
    $('#activatedb').hide();
    $('#activatedc').hide();
    $('#activatedd').hide();
    $('#activatede').hide();
            

    $('#buttona').hover(
        function mouseover() {
    $('#activateda').show();
    }, 
        
        function mouseleave() {
        $('#activateda').hide();
    });

    $('#buttonb').hover(
        function mouseover() {
    $('#activatedb').show();
    }, 
        
        function mouseleave() {
        $('#activatedb').hide();
    });

    $('#buttonc').hover(
        function mouseover() {
    $('#activatedc').show();
    }, 
        
        function mouseleave() {
        $('#activatedc').hide();
    });

$('#buttond').hover(
        function mouseover() {
    $('#activatedd').show();
    }, 
        
        function mouseleave() {
        $('#activatedd').hide();
    });

    $('#buttone').hover(
        function mouseover() {
    $('#activatede').show();
    }, 
        
        function mouseleave() {
        $('#activatede').hide();
    });

  

});
/////////////
        $(".key").hide(); 

    }
     else if(val=="5"){

        drawRaces();
        $('.boroughsContainer').css('display','none')
        $(".intro").css("display","none");
        $('.displaytext1').css('display','none');
        $('.displaytext2').css('display','none');
        $('.displaytext3').css('display','none');


        $('#chartgraphs').css("display","none");
        $('#methods').css('display','block');
        $(".key").hide(); 

    };
})


   


